package ControladorPago;

import java.util.*;

public interface MedioPago {
    void Pagar(Float monto);

}