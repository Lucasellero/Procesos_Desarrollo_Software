package ControladorCurso;

import java.util.*;

public class Aula {

    public Aula() {
    }

    private int numeroAula;

    private int capacidadMax;

    private float Horario;

}